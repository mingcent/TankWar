using System;

namespace FixPoint
{
	public struct VLine
	{
		public VInt2 point;

		public VInt2 direction;
	}
}