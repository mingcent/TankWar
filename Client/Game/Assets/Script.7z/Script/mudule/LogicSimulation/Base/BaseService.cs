﻿using System;

public class BaseService
{
    public World world;
}

