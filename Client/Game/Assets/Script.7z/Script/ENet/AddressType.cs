﻿namespace ENet
{
    public enum AddressType
    {
        IPv4 = 0
    }
}