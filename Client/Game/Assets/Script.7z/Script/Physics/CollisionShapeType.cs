using System;

public enum CollisionShapeType
{
	None,
	Box,
	Sphere,
	CylinderSector
}
